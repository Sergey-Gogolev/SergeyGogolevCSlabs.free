#include <iostream>
#include <fstream>
#include <chrono>
#include <random>

#define MAXSIZE 100000000

using namespace std;

unsigned int M[MAXSIZE];
unsigned int TMP[MAXSIZE];
struct array_min{unsigned int val; unsigned int pos;};

void for_sort_swap(unsigned int pos1,unsigned int pos2){
	int temp;
	temp = M[pos1];
	M[pos1] = M[pos2];
	M[pos2] = temp;
}

unsigned int rand_uns(unsigned int min, unsigned int max)
{
    unsigned seed = std::chrono::steady_clock::now().time_since_epoch().count();
    static std::default_random_engine e(seed);
    std::uniform_int_distribution<int> d(min, max);
    return d(e);
}

void array_randfill(unsigned int n, unsigned int min, unsigned int max)
{
    for (unsigned int i = 0; i < n; i++)
        M[i] = rand_uns(min, max);
}

void array_zerofill(unsigned int n)
{
    for (unsigned int i = 0; i < n; i++)
        M[i] = 0;
}

void print_array(unsigned int n)
{
    for (unsigned int i = 0; i < n; i++)
        cout << M[i] << " ";
}

bool array_check(unsigned int n)
{
    for (unsigned int i = 0; i < n-1; i++)
        if (M[i] > M[i+1]){
        cout << "NOT OK";
        return false;}
    cout << "OK";
    return true;
}

void sort_bubble(unsigned int n)
{
    unsigned int tmp;
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (M[j] > M[j + 1])
                for_sort_swap(j, j+1);
}

void sort_bad_bubble(unsigned int n)
{
    unsigned int tmp;
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - 1; j++)
            if (M[j] > M[j + 1])
                for_sort_swap(j, j+1);
}

void sort_selection(unsigned int n)
{
    unsigned int tmp;
    array_min res;
    for (unsigned int i = 0; i < n-1; i++){
        res.val = 10000;
        res.pos = i;
        for (unsigned int j = i+1; j < n; j++)
            if (M[j] < res.val){
                res.pos = j;
                res.val = M[j];
            }
        if (M[i] > res.val)
            for_sort_swap(i, res.pos);
    }
}

bool for_quicksort_array_check(unsigned int begini, unsigned int endi)
{
    for (unsigned int i = begini; i <= endi; i++)
        if (M[i] > M[i+1])  return false;
    return true;
}

void for_quicksort_tmp_array(unsigned int begini, unsigned int endi)
{
    for (unsigned int i = begini; i <= endi; i++)   TMP[i] = M[i];
}

void sort_quicksort(unsigned int begini, unsigned int endi) {
    if (for_quicksort_array_check(begini, endi))  return;
    if (endi < 1 + begini) return;
    if (endi == 1 + begini)
    {
        for_sort_swap(begini, endi);
        return;
    }

    unsigned int pivot;
    pivot = (unsigned int)(begini + endi)/2;
    unsigned int pval = M[pivot];

    for_quicksort_tmp_array(begini, endi);
    unsigned int l_end, r_begin;

    unsigned int ki = begini;
    for (unsigned int i = begini; i <= endi; i++)
        if (TMP[i] < pval){
            M[ki] = TMP[i];
            ki++;
        }

    if (ki != begini) l_end = ki;
    else l_end = begini;

    for (unsigned int i= begini; i <= endi; i++)
        if (TMP[i] == pval){
            M[ki] = TMP[i];
            ki ++;
        }

    r_begin = ki;

    for (unsigned int i = begini; i <= endi; i++)
        if (TMP[i] > pval){
            M[ki] = TMP[i];
            ki ++;
        }

    sort_quicksort(begini, l_end);
    sort_quicksort(r_begin, endi);
}


void sort_gnome(unsigned int n)
{
    int i = 1;
    int j = 2;
    while (i < n)
        if (M[i - 1] < M[i])
        {
            i = j;
            j = j + 1;
        }
        else
        {
            for_sort_swap(i - 1, i);
            i = i - 1;
            if (i == 0)
            {
                i = j;
                j = j + 1;
            }
        }
}

void for_sort_heapify(unsigned int n,unsigned int i)
{
    unsigned int largest = i;
    unsigned int l = 2*i + 1;
    unsigned int r = 2*i + 2;

    if (l < n && M[l] > M[largest])
        largest = l;

    if (r < n && M[r] > M[largest])
        largest = r;

    if (largest != i)
    {
        for_sort_swap(i, largest);
        for_sort_heapify(n, largest);
    }
}

void sort_heapsort(int n)
{
    for (int i = n / 2 - 1; i >= 0; i--)
        for_sort_heapify(n, i);
    for (int i=n-1; i >= 0; i--)
    {
        for_sort_swap(0, i);
        for_sort_heapify(i, 0);
    }
}

void sort_comb(unsigned int n)
{
    float reduction_factor = 1.25;
    unsigned int step = n;
    int k;
    while (n>1)
    {
        step /= reduction_factor;
        if (step < 1)   step = 1;
        k = 0;
        for (int i = 0; i + step < n; i ++)
        if (M[i] > M[i+step])
        {
            for_sort_swap(i, i+step);
            k=i;
        }
        if (step == 1)  n = k + 1;
    }
}

int main()
{

    array_zerofill(MAXSIZE);
    ofstream file("C:/Users/gogol/Desktop/CS/labs/data/4_s electionantisorted.csv", ios::out);
    for (int n = 1000; n <= 20000; n += 1000){
        for (unsigned int i = 0; i < n; i++)    M[i]=n-i;
        //array_randfill(n, 0, n);
        auto start = std::chrono::high_resolution_clock::now();
        sort_bad_bubble(n);
        auto end = std::chrono::high_resolution_clock::now();
        auto nsec = end - start;
        file << n << '\t' <<nsec.count() << endl;
        array_check(n);
    }

    return 0;
}
